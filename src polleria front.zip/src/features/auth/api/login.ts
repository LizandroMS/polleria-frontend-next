import { CURRENT_PROJECT_CODE } from '../constants/project-code';
import { AuthResponse, LoginPayload } from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL;

export async function login(payload: LoginPayload): Promise<AuthResponse> {
  const response = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      email: payload.email,
      password: payload.password,
      /**
       * Nota para mí:
       * El backend de autenticación es compartido con otros proyectos.
       * Desde el frontend de pollería siempre envío POL para que el login
       * valide el acceso dentro de user_project_access sin afectar ROP.
       */
      projectCode: CURRENT_PROJECT_CODE,
    }),
  });

  const json = await response.json();

  if (!response.ok || !json.success) {
    throw new Error(json.message ?? 'No se pudo iniciar sesión');
  }

  return json.data;
}
